from . import cancellation_policy
from . import hotel_facility_type
from . import hotel_facility_master
from . import hotel_type
from . import meal_type
from . import room_type
from . import hotel_image
# from . import product_image
from . import hotel_information

from . import room_info
from . import room_rate
from . import tt_banner
from . import landmark
from . import hotel_compare
from . import res_country
from . import tt_master_vendor
from . import provider_code

# from . import tb_provider_hotel
from . import hotel_reservation
from . import hotel_reservation_details

from . import scrapper_history
from . import read_file
from . import res_config
